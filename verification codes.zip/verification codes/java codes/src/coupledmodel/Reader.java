package coupledmodel;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Pouyan Pirnia 2017
 * This subclass reads YADE's output file (yaderesults.txt) and save it in an array. YADE's output file is then moved to a folder named results.
 */

public class Reader {
public String[] row; 
    
public void method (String MainPath, String YadeOutputFile, String SavingFolder) {
    
//      Open and read YADE's output file (yaderesults.txt)  
        File file = new File(MainPath+YadeOutputFile);
        try {

        Scanner sc = new Scanner(file);
  
//      Move to the second line assuming the first line contains the header.
        String nextLine = sc.nextLine();
        
//      Break on any amount of spaces
        String reg = "(\\s)+";

//      This is printing all columns, you can access each column from row using the array indexes, example row [0], row [1], row [2]...
        while (sc.hasNext()) {       
            row = sc.nextLine().split(reg);
        }
        sc.close();
        } 
        catch (FileNotFoundException e) {
        }

//      Move YADE's output file "yaderesults.txt" from the first directory to a specific folder "results" and save it there        
        try{
    		 		
    	    if(file.renameTo(new File(SavingFolder+ file.getName()))){
    		System.out.println("File was moved successfully!");
    	    }
           else{
    		System.out.println("File could not be moved!");
    	    }
    	    
    	}catch(Exception e){
    		e.printStackTrace();
    	}
  
}


public String[] returnsvel(){

//      Save the results in an array    
        return row;
    }
    
}

