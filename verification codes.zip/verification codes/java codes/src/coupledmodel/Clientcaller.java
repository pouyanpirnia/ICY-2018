package coupledmodel;
import java.io.File;
import java.io.IOException;

/**
 *
 * @author Pouyan Pirnia 2017
 * This subclass runs the YADE script using the client-server as an agent  
 */

public class Clientcaller {
    
    public void caller (String MainPath, String YadeModel, String YadeOutputFile) throws IOException{

//      Launch a terminal on Ubuntu and run the command inside the quotation marks and in the YadeModel string         
        String cmd= "/usr/bin/xterm -e python client.py"+' '+YadeModel;
    	Runtime rt = Runtime.getRuntime();
    	Process pr = rt.exec(cmd);  
        
//      Following syntaxes stop running the rest of program until YADE's output file named yaderesults.txt appears     
        File f = new File(MainPath+YadeOutputFile);
        while (!f.exists()) {
            try { 
                Thread.sleep(100);
            } catch (InterruptedException ie) { /* safe to ignore */ }
        }          
    
        
}
}
