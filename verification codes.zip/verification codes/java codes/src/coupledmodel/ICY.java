package coupledmodel;
import com.comsol.model.Model; 
import com.comsol.model.util.ModelUtil;
import java.io.*;
import static java.lang.System.*;
import java.util.Arrays;
import java.util.Properties;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author Pouyan Pirnia 2017
 * This is the main class of iCY. It calls two other classes named "clientcaller" and "Reader".
 * It controls both YADE and COMSOL models.
 */

public class ICY {


    public static void main(String args[])throws Throwable {
        
//      Connect to a previously launched COMSOL server
        ModelUtil.connect("localhost", 2036);
        
//      Shows the calculation progress in a window  
        ModelUtil.showProgress(true); 
        
//      Load the COMSOL model file (created previously in GUI) using its directory and name it (e.g., test.mph)
        Model ModeleCOMSOL = ModelUtil.load("model3d","test.mph");
        
//      Create a numerical results feature with a tag (e.g., "Eval1")
        ModeleCOMSOL.result().numerical().create("Eval1","EvalGlobal");
        
//      Define a dataset for the results feature         
        ModeleCOMSOL.result().numerical("Eval1").set("data","dset1");

//      Read parameters and paths from property file                                      
        Properties prop=new Properties();
        
//      Set the define.properties address         
        FileReader reader=new FileReader ("src//define.properties");        
        prop.load(reader);        
        
//      Read parameters from the property file         
        String MainPath=prop.getProperty("MainPath");        
        String YadeModel=prop.getProperty("YadeModel"); 
        String YadeOutputFile=prop.getProperty("YadeOutputFile"); 
        String SavingFolder=prop.getProperty("SavingFolder");         
        String LastVelocityFile=prop.getProperty("LastVelocityFile");
        String DragForce=prop.getProperty("DragForce");
        String numbsim=prop.getProperty("numberofsimulation");        
        
//      Convert number of simulation from String to integer        
        int numberofsimulation = Integer.parseInt(numbsim);        
        System.out.println(numberofsimulation);        
        
        
//      The  following For loop controls the interface, the following tasks are run in order:
//      Running YADE,
//      Reading the YADE results,
//      Sending the YADE results to COMSOL,
//      Running the COMSOL model, and 
//      Printing the results on screen and write them in a output file                
        for (int n=0;n<numberofsimulation;n++){
            
//      Print the current simulation number on the screen             
        System.out.println("simulation number"+(n+1)); 
            
//      Call the subclass named "clientcaller" to run YADE
        Clientcaller yade= new Clientcaller();   // Create an object named "yade" from the subclass "clientcaller"
        yade.caller(MainPath, YadeModel, YadeOutputFile);   //Pass "yade" into the method "caller"
        
//      Declare YADE simulation is completed         
        System.out.println("velserie.txt is written"); 
         
    
//      Call the subclass named "Reader" to read the output file of YADE
        Reader obj= new Reader();
        obj.method(MainPath, YadeOutputFile, SavingFolder);
        
//      Print the last velocity on screen        
        System.out.println("This is lastvel :"+obj.returnsvel());
        
//      The data in YADE's output file is written in an array named "results" 
        String[] results = obj.returnsvel();
        

//      Print objects inside the array "results"       
        for(int i=0; i<results.length;i++)                       
        System.out.println(results[i]);

        String lastvel = results[2]; 
        
//      Write the last velocity in a text file named lastvel. This value is used by Yade for the next time step This velocity is applied as the initial velocity of falling sphere         
        try (PrintWriter out = new PrintWriter(MainPath+LastVelocityFile)) {
            out.write(lastvel);
        }
            System.out.println("lastvel.txt is written");
                        
//      Rename YADE's output file "velserie.txt" in results folder with a name including the simulation number         
        File nfile = new File(SavingFolder+LastVelocityFile);
        nfile.renameTo(new File(nfile.getParentFile(), "newFilename"+(n+1)+".txt"));         
               
//      Define the velocity in the GUI   
        ModeleCOMSOL.param().set("Velocity", lastvel);

//      Run the COMSOL model            
        ModeleCOMSOL.sol("sol1").run();
       
//      Integrate Drag force around the sphere in water flow direction (the total stress in the y-direction).
        ModeleCOMSOL.result().numerical("Eval1").set("expr", "intop1(spf.T_stressy)");

//      Save the COMSOL model under a name that includes the simulation number     
        ModeleCOMSOL.save("simulation"+(n+1)+".mph"); 

//      Write the COMSOL model results in a text file named "dragforce.txt"
        double [][] data;
        data = ModeleCOMSOL.result().numerical("Eval1").getReal();
        
        try{
            File fac=new File(MainPath+DragForce);

            FileWriter pw=new FileWriter(fac);
         	for (int i = 0; i<data.length; i++){    
	        for(int j = 0; j<data[0].length; j++){
                    pw.write(data[i][j] + ",");
                    pw.close();
                    System.out.println("dragforce is written:"+data[i][j]);
                    System.out.println("#####################################");
                }
                }	
   
        }catch (IOException e){
            out.println("error");
        }

        }

    ModelUtil.showProgress(false);
    System.out.println("Simulation is finished");       
    System.exit(0);
    }
 
}
   

