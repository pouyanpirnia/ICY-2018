import re
from yade import pack, plot, geom, utils

# DATA COMPONENTS #######################################################################################
######## Receive data from server########################################################################

params= sys.argv[1:] #get everything after the test3.py

fd= params[0]   #put the drag force value in fd
t=fd.split(",")  # remove ","  
fdz=float(t[0])
fdz=-1*fdz
print fdz

vel=params[1]  #put the velocity value in vel
zvel=float(vel)
print zvel

###########################################################################################################
######## Test information #################################################################################

E1 = 1e9   #Young's modulus (Pa)
poisson1 = 0.3   # Poison ratio
frictionAngle = 0.07  #Friction angle
density1 = 2650   #sphere density  kg/m3
densitywater = 1000   #water density
g = 9.80665   #gravity m/s2
r=.00005   #radius of sphere (m)
d=.0001    #diameter of sphere (m)

###########################################################################################################
############ Defining materials for spheres ###############################################################

O.materials.append(FrictMat(young=E1,poisson=poisson1,frictionAngle=frictionAngle,density=density1, label='mat_spheres'))

O.bodies.append(utils.sphere([2,0.01,10],.00005,color=[1,1,0], material='mat_spheres'))

# FUNCTIONAL COMPONENTS ##########################################################################
# simulation loop  ###############################################################################

O.engines=[
    ForceResetter(),
    InsertionSortCollider([Bo1_Sphere_Aabb(),Bo1_Facet_Aabb()]),
    InteractionLoop(
        [Ig2_Sphere_Sphere_ScGeom(),Ig2_Facet_Sphere_ScGeom()],
        [Ip2_FrictMat_FrictMat_FrictPhys()],
        [Law2_ScGeom_FrictPhys_CundallStrack()]

    ),
    GravityEngine(gravity=(0,0,-9.80665)),   # apply gravity force to particles
    NewtonIntegrator(damping=0.509),    # damping: numerical dissipation of energy
    PyRunner(command='velocity()',realPeriod=.5),   # call the velocity() function (defined below) every .5 second
    PyRunner(command='myAddPlotData()',iterPeriod=1) # call function 'myAddPlotData()' every 1 iteration 
]

 
O.dt=.001   # set time step

O.bodies[0].state.vel=(0,0,zvel)   # apply velocity (calculated in the last iteration of previous simulation) on sphere

bz=(4.0/3.0*3.1416*r**3)*densitywater*g   # buoyancy force

O.forces.addF(0,(0,0,bz+fdz),1)   # apply buoyancy and drag forces on the sphere

w=(4.0/3.0*3.1416*r**3)*density1*g  # weight of sphere
print 'w :', w

F=w-(bz+fdz)   # the balance force
print 'F :', F

def velocity():
    plot.saveDataTxt('yaderesults.txt')  # save results in a text file, this is Yade's outputFile
    O.pause()

def myAddPlotData():
    if O.iter<2:
        plot.addData(t=O.time,F=O.forces.f(0).norm(),Vz=O.bodies[0].state.vel[2], Position=O.bodies[0].state.pos[2])  #selected parameters will be written on the text file

plot.plots={'t':('F','Vz')}
plot.plot()
O.saveTmp()
O.run()
O.wait()
quit()
