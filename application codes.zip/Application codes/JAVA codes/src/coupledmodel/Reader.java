package coupledmodel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.Scanner;


/**
 *
 * @author Pouyan Pirnia
 */

public class Reader {
public String[] row; 
    

public void method (String MainPath, String YadeOutputFile, String SavingFolder) {
    
    
//      Open and read YADE's output file (yaderesults.txt)        
        File file = new File(MainPath+YadeOutputFile);
        
        try {
            
        Scanner sc = new Scanner(file);
        
//      Read the first line, I suppose the first line is header
        String nextLine = sc.nextLine();
        
//      Regex to break on any ammount of spaces
        String regex = "(\\s)+";
        String[] header = nextLine.split(regex);
        
        
//      This is printing all columns, you can 
//      access each column from row using the array
//      indexes, example header[0], header[1], header[2]...
        while (sc.hasNext()) {
            row = sc.nextLine().split(regex); 
        }
        
        sc.close();
        } 
        catch (FileNotFoundException e) {
        }

//      Remove the YADE's output file "yaderesults.txt" from the first directory to a specific folder "results" and save it there
    	try{
            
    	    if(file.renameTo(new File(SavingFolder + file.getName()))){
    		System.out.println("File is moved successfully!");
                }else{
    		System.out.println("File is failed to move!");
    	    }
    	    
    	}catch(Exception e){
    		e.printStackTrace();
    	}   
}
public String[] returnskn(){
        return row;
}    
}
