
package coupledmodel;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
/**
 *
 * @author pouyan
 */
public class Clientcaller {
    
    public void caller (int n, String MainPath, String YadeModel, String YadeOutputFile) throws IOException{
               
//      Launch a terminal on Ubuntu and run the comments inside two quotation marks  
        String cmd= "/usr/bin/xterm -e python client.py"+' '+YadeModel+' '+n;
    	Runtime rt = Runtime.getRuntime();
    	Process pr = rt.exec(cmd);  
        
//      Following syntaxes stop running the rest of program until YADE's output file named yaderesults.txt be appeared 
        
        File f = new File(MainPath+YadeOutputFile);
        while (!f.exists()) {
            try { 
                Thread.sleep(100);
        } catch (InterruptedException ie) { /* safe to ignore */ }
        }        
        
}
}
