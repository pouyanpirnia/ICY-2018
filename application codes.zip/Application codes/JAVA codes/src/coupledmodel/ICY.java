package coupledmodel;
import com.comsol.model.Model; 
import com.comsol.model.util.ModelUtil;
import java.io.*;
import static java.lang.System.*;
import java.util.Arrays;
import java.util.*;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author Pouyan Pirnia
 */

public class ICY {

    public static void main(String args[])throws Throwable {
                             
//      Launch the COMSOL model 
        ModelUtil.connect("localhost", 2036); 
        
//      shows the progress of calculation in a window        
        ModelUtil.showProgress(true); 
        
//      Load the COMSOL model file (created previousely in GUI) from a directory and names it (e.g., piping.mph)
        Model ModeleCOMSOL = ModelUtil.load("model1d","test.mph");
        
//      Creates a numerical results feature with the tag (e.g., "Eval1")
        ModeleCOMSOL.result().numerical().create("Eval1","EvalPoint");
        
//      Set a data set for the results feature for the points specified previously in GUI with the tag cpt1 (1D point evaluation)      
        ModeleCOMSOL.result().numerical("Eval1").set("data", "cpt1");

        double sum = 0; 
        
//      Reead parameters and pathes from the properties file                                      
        Properties prop=new Properties();
        
//      Set the define.properties address         
        FileReader reader=new FileReader ("src//define.properties");        
        prop.load(reader);
        
//      Reead parameters from propertiy file         
        String MainPath=prop.getProperty("MainPath");        
        String YadeModel=prop.getProperty("YadeModel"); 
        String YadeOutputFile=prop.getProperty("YadeOutputFile"); 
        String SavingFolder=prop.getProperty("SavingFolder");         
        String numbsim=prop.getProperty("numberofsimulation");        
        
//      Convert number of simulation from String to integer        
        int numberofsimulation = Integer.parseInt(numbsim);        
        System.out.println(numberofsimulation);
        
//      The  following For loop controls the interface, the following tasks are run in order:
//      Running YADE,
//      Read the YADE results,
//      Set it for COMSOL GUI,
//      Run the COMSOL model, and 
//      Print the results on screen and write them in a output file         
        for (int n=0;n<numberofsimulation;n++){
            
    //      Print the current simulation number on the screen       
            System.out.println("simulation number"+(n+1)); 

    //      Call the subclass named "clientcaller" to run YADE
            Clientcaller yade= new Clientcaller();   // Create an object named "yade" from the subclass "clientcaller"
            yade.caller(n, MainPath, YadeModel, YadeOutputFile);   //Pass "yade" into the method "caller" with the current number of simulation (n) and the property file info

    //      Declare YADE simulation is completed       
            System.out.println("YADE simulation is completed"); 

    //      Call the subclass named "Reader" to read the output file of YADE
            Reader obj= new Reader();
            obj.method(MainPath, YadeOutputFile, SavingFolder);

    //      The data in YADE's output file is written in an array named "results"  
            String[] results = obj.returnskn();

    //      Print objects inside the array "results"       
            for(int i=0; i<results.length;i++)                       
            System.out.println(results[i]);
                          
    //      Rename the YADE's output file "pip18.txt in results folder regarding the simulation number    
            File nfile = new File(SavingFolder+YadeOutputFile);
            nfile.renameTo(new File(nfile.getParentFile(), "newFilename"+(n+1)+".txt"));         

    //      Define the hydraulic head in GUI  
            ModeleCOMSOL.param().set("Hupstream", .23);

    //      Define the parameters (permeability values (k) and porosity values (n)) in GUI        
            ModeleCOMSOL.param().set("k1", results[0]);
            ModeleCOMSOL.param().set("k2", results[1]);
            ModeleCOMSOL.param().set("k3", results[2]);
            ModeleCOMSOL.param().set("k4", results[3]);
            ModeleCOMSOL.param().set("k5", results[4]);
            ModeleCOMSOL.param().set("n1", results[5]);
            ModeleCOMSOL.param().set("n2", results[6]);
            ModeleCOMSOL.param().set("n3", results[7]);
            ModeleCOMSOL.param().set("n4", results[8]);
            ModeleCOMSOL.param().set("n5", results[9]);


    //      The object number 10 in the results array is number of eroded particles accumulated in the container at the end of each global time step      
            String aString=results[10];
            System.out.println("string result10: "+aString);

    //      convert string to double        
            double aDouble = Double.parseDouble(aString);
            System.out.println(aDouble);

    //      sum the new amount (aDouble) with the previous value (sum)
            sum=sum+aDouble;
            System.out.println("number of eroded particles total: "+sum);       
            System.out.println("cumulative weight of eroded particles total: "+sum*0.000000056123);    

    //      Run the COMSOL model   
            ModeleCOMSOL.sol("sol1").run();   
            System.out.println("Running COMSOL");

    //      Define the pressure expression for "Eval1"   
            ModeleCOMSOL.result().numerical("Eval1").set("expr", "p");


    //      Write the COMSOL model results on a text file named "pressure.txt"
            double [][] data;
            data = ModeleCOMSOL.result().numerical("Eval1").getReal();

            int rows = data.length;
            System.out.println("number of pressur rows: "+rows);
            int cols = data[0].length;
            System.out.println("number of pressure columns: "+cols);

    //      Setting pressure file directory from define.properties 
            String PressureFilePath=prop.getProperty("MainPath")+prop.getProperty("PressureResultFile");                            
            
            try{
                File fac=new File(PressureFilePath);

                FileWriter pw=new FileWriter(fac);
                
                for (int i = 0; i<data.length; i++){
                    for(int j = 0; j<data[0].length; j++){
                        pw.write(data[i][j] + ",");
                        System.out.println("pressure in level"+(i+1)+" is :"+data[i][j]);             
                    }
                }

            pw.close();
            System.out.println("#####################################");


            }catch (IOException e){
                out.println("error");
            }

        }

    ModelUtil.showProgress(false);
    System.out.println("Simulation is finished");       
    System.exit(0);
    }
 
}
   

