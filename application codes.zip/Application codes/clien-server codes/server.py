import SocketServer
import subprocess
import os.path
import signal
import re

class MyTCPHandler(SocketServer.BaseRequestHandler):

    def handle(self):

        self.data = self.request.recv(1024).strip() #receive the string were sent by client and remove the extra whitepace from front and back of the string ( test"+' '+n)

        params = self.data.split(' ')  # split the string by space ("test", "n")

        function = params[0]  #put the first parameter in function (function = "test")

        counter = params[1]   # function = "n"

        with open('pressure.txt','r') as f:  #open COMSOL's output file (pressure.txt) and read it
            dp=f.read(300)
            f.close()

        if function == "test":  #if Yade's script (test.py) and the output file (yaderesults.txt), pressure values from COMSOL (dp) and simulation number (counter) are available go to function doTest
            self.doTest('test.py', 'yaderesults.txt', dp, counter)  
                      
        else:
            self.request.sendall("ERROR: Function not found")   # unless show the message "Function not found"

        
    def doTest(self, testFile, outputFile, dp, counter):
        try:

            paramsString=dp.rstrip() #remove the rest of characters in the line without this syntax the next parameter written in the next line

            counterstring=counter.rstrip()

            command = 'python yade -j8 -x '+testFile+' '+paramsString+' '+counterstring  #This is the command line for terminal to run Yade's script (pip18.py) 
            
            print 'command: '+command
            
            process = subprocess.Popen(command.strip(), shell=True)   #Run the command.strip() or open the process
            
            while not os.path.isfile(outputFile):   #return true if path is an existing regular file
                pass
            
            content = ''  # content is defined as space
            
            while not self.isNotEmptyContent(content):   # Open and read the outputFile if the outputFile is not empty based on the function isNotEmptyContent
                with open(outputFile, 'r') as content_file:
                    content = content_file.read()
                    content_file.close()
            
            os.kill(process.pid, signal.SIGUSR1)   #kill the process
          
            self.request.sendall(content)
            
        except Exception as e:          # report a message "ERROR" on terminal if doTest is not completed
            self.request.sendall('ERROR: '+str(e))
            
            
    def isNotEmptyContent(self, content):
        return re.search("\w+", content)  # searching in the file for defined charachter in content

if __name__ == "__main__":
    HOST, PORT = "localhost", 64000
    server = SocketServer.TCPServer((HOST, PORT), MyTCPHandler)
    server.serve_forever()
