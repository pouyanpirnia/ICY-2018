# import yade modules that we will use below
import re
from yade import pack, plot, geom, utils, ymport, export, bodiesHandling

# DATA COMPONENTS #######################################################################################
######## Receive data from server########################################################################

params= sys.argv[1:] #get everything after the test.py

dp= params[0] #put 7 pressure values in string format in dp 
print dp
t=dp.split(",") #split dp by "," and set each pressure value in a new character 
a=(t[0])
b=(t[1])
c=(t[2])
d=(t[3])
e=(t[4])
f=(t[5])
g=(t[6])
print a,b,c,d,e,f,g

# convert string to float
p1=float(a)
p2=float(b)
p3=float(c)
p4=float(d)
p5=float(e)
p6=float(f)
p7=float(g)
print 'p1,p2,p3,p4,p5,p6,p7 :', p1,p2,p3,p4,p5,p6,p7

dp1=p1-p2
dp2=p2-p3
dp3=p3-p4
dp4=p4-p5
dp5=p5-p6
dp6=p6-p7
print'dp1,dp2,dp3,dp4,dp5,dp6 :', dp1,dp2,dp3,dp4,dp5,dp6

# counter is the number of the current simulation
global counter
counter=params[1]
print 'counter :', counter

# load YADE's simulation from previous time step, it involves particles and facets positions and forces
O.load('test'+counter+'.yade')
###########################################################################################################
######## Test information #################################################################################
r1 = .003/2.0 # coarse particles radius (m)
r2 = .00035/2.0 # fine particles radius (m)
E1 = 1e7   # filter Young's modulus
E2 = 1e7  # soil Young's modulus
poisson1 = 0.3  # filter poisson ratio
poisson2 = 0.3  # sand Young's modulus
frictionAngle = .3
density1 = 2500  # kg/m3
density2 = 2500  # kg/m3
densitywater = 1000 # kg/m3
g=-9.806 # gravity m/s2
nf=160   # number of filter Particles
ns=15000 # number of fine Particles
Gs=2.5 
plate=0
npc2=0
npc3=0
npc=0
###########################################################################################################
############ Defining materials for spheres ###############################################################
#O.materials.append((FrictMat(young=E2,poisson=poisson2,frictionAngle=frictionAngle,density=250000, label = 'mat_wal2')))
#mat2 = O.materials[1]

## In this section eroded particles in the container and their arrays are erased and equal amount of the same particles are generated at the top fine particles layer  #####
npc2 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<.03) and b.shape.radius == r2))/r2
print 'number of small particles in the container :', npc2
npc=npc2
npc=int(npc) 
print 'npc:', npc


sp1 = pack.SpherePack()
sp1.makeCloud((0,0,.1),(0.01,0.01,.15),rMean=r2,num=npc)
for b in O.bodies:
    if isinstance(b.shape,Sphere) and b.state.pos[2]<0.03: O.bodies.erase(b.id)

sp=SpherePack(); sp.fromSimulation()
O.reset()
#mat1 = O.materials.append((FrictMat(young=E1,poisson=poisson1,frictionAngle=frictionAngle,density=100*density1, label = 'mat_wal')))
#mat2 = O.materials.append((FrictMat(young=E2,poisson=poisson2,frictionAngle=.5,density=250000, label = 'mat_wal2')))

O.materials.append((FrictMat(young=E1,poisson=poisson1,frictionAngle=.6,density=100*density1),FrictMat(young=E2,poisson=poisson2,frictionAngle=.3,density=100*density1,label = 'mat_wal2')))

mat1,mat2 = [O.materials[i] for i in (0,1)]


sp1.toSimulation()
sp.toSimulation()


bodies1 = [b for b in O.bodies if isinstance (b.shape,Sphere) and b.shape.radius==r1]

for b in bodies1:
    b.shape.color = (1,1,0)
    b.mat = mat2
bodies2 = [b for b in O.bodies if isinstance (b.shape,Sphere) and b.shape.radius==r2]

for b in bodies2:
    b.shape.color = (0,1,0)
    b.mat = mat2

kw={'material':0}
O.bodies.append(utils.geom.facetBox((0.005,0.005,0.1),(0.005,0.005,0.1),wallMask=31))
O.bodies.append(ymport.gmsh('4.mesh', shift=Vector3(0, 0, .03), scale=.001, orientation=Quaternion((0, 0, 0), 0), **kw))
print 'len(O.bodies) final :',len(O.bodies)

# FUNCTIONAL COMPONENTS ##########################################################################
# simulation loop  ###############################################################################
O.engines=[
    ForceResetter(),
    InsertionSortCollider([Bo1_Sphere_Aabb(),Bo1_Facet_Aabb(),Bo1_Wall_Aabb()]),
    InteractionLoop(
	# the loading plate is a wall, we need to handle sphere+sphere, sphere+facet, sphere+wall
	[Ig2_Sphere_Sphere_ScGeom(),Ig2_Facet_Sphere_ScGeom(),Ig2_Wall_Sphere_ScGeom()], # collision geometry
	[Ip2_FrictMat_FrictMat_FrictPhys()],   # collision "physics"
	[Law2_ScGeom_FrictPhys_CundallStrack()]     # contact law -- apply forces
    ),
    NewtonIntegrator(gravity=(0,0,g),damping=0.4),  # apply gravity force and damping: numerical dissipation of energy 
    PyRunner(command='func()',virtPeriod=.5,label='checker1'), # call the func function (defined below) every 3000 iteration     virtPeriod
    PyRunner(command='save()',virtPeriod=.51,label='checker2')
]

# set timestep to a fraction of the critical timestep
O.dt=1*utils.PWaveTimeStep()
print 'O.dt=', O.dt
O.trackEnergy=True
O.resetTime() #Reset simulation time


###############################################################################################################
############ Calculation Section ##############################################################################
###############################################################################################################
print 'BOTTOM LAYER INFORMATION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%'
h1=max(b.state.pos[2]+b.shape.radius for b in O.bodies if isinstance(b.shape,Sphere) and b.shape.radius==r1)  # h1 is the height of filter layer
print 'h1=', h1
ParticlesVolume=sum(4.0/3.0*3.1416*b.shape.radius**3 for b in O.bodies if (isinstance (b.shape,Sphere) and (b.state.pos[2]<h1 and b.state.pos[2]>.03)))  #volume of filter particles
print 'ParticlesVolume=', ParticlesVolume
boxArea=.01*.01
BoxVolume=(h1-.03)*boxArea
print 'BoxVolume=', BoxVolume
n1=1-(ParticlesVolume/BoxVolume)
print 'porosity of bottom layer :', n1


print 'TOP LAYER INFORMATION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%'
h2=max(b.state.pos[2]+b.shape.radius for b in O.bodies if isinstance(b.shape,Sphere) and b.shape.radius==r2)-h1    # h2 is the height of top of the fine particle layer
print 'h2=', h2
soilVolume=sum(4.0/3.0*3.1416*b.shape.radius**3 for b in O.bodies if isinstance (b.shape,Sphere) and (b.state.pos[2]<h2 and b.state.pos[2]>h1) and b.shape.radius==r2)
print 'soilVolume=', soilVolume
soilLayerVolume=h2*boxArea
n2=(soilLayerVolume-soilVolume)/soilLayerVolume
print 'porosity of top layer:', n2

print '1st filter layer information ########################################'
totalThickness=h1-.03
boxvolume1=boxArea*totalThickness*1.0/5.0
print 'boxvolume1:', boxvolume1
nfp1 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<h1 and b.state.pos[2]>4.0/5.0*totalThickness+.03) and b.shape.radius == r1))/r1
print 'number of filter particles in Layer1 :', nfp1
tvfp1=(4.0/3.0*3.1416*r1**3)*nfp1
print 'total volume of filter particles in Layer1 :', tvfp1
############################################################################
nsp1 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<h1 and b.state.pos[2]>4.0/5.0*totalThickness+.03) and b.shape.radius == r2))/r2
print 'number of small particles in Layer1 :', nsp1
tvsp1=4.0/3.0*3.1416*(r2**3)*nsp1
print 'total volume of small particles in Layer1 :', tvsp1
##########################################################################
tpv1=tvfp1+tvsp1 
print 'total particles volume in Layer1 :', tpv1
pfp1=(tvfp1/tpv1)
print 'proportion of filter particles in layer1 :', pfp1
psp1=(tvsp1/tpv1)
print 'proportion of small particles in layer1 :', psp1
nf1=1-(tpv1/boxvolume1)
print 'porosity of filter layer1:', nf1

S1=3/(r1*density1)  #m2/kg
S2=3/(r2*density2)
Ss1=S1*pfp1+S2*psp1
print 'S1,S2,Ss1:', S1,S2,Ss1

e1=nf1/(1-nf1)
k1=(math.sqrt(10)*(e1**3))/((Gs**2)*(Ss1**2)*(1+e1))
print 'void ratio and permeability in layey1 :', e1, k1

print '2nd filter layer information ##########################################################################'
nfp2 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<4.0/5.0*totalThickness+.03 and b.state.pos[2]>3.0/5.0*totalThickness+.03) and b.shape.radius == r1))/r1
print 'number of filter particles in Layer2 :', nfp2
tvfp2=(4.0/3.0*3.1416*r1**3)*nfp2
print 't1otal volume of filter particles in Layer2 :', tvfp2
############################################################################
nsp2 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<4.0/5.0*totalThickness+.03 and b.state.pos[2]>3.0/5.0*totalThickness+.03) and b.shape.radius == r2))/r2
print 'number of small particles in Layer2 :', nsp2
tvsp2=4.0/3.0*3.1416*(r2**3)*nsp2
print 'total volume of small particles in Layer2 :', tvsp2
##########################################################################
tpv2=tvfp2+tvsp2 
print 'total particles volume in Layer2 :', tpv2
pfp2=(tvfp2/tpv2)
print 'proportion of filter particles in layer2 :', pfp2
psp2=(tvsp2/tpv2)
print 'proportion of small particles in layer2:', psp2
nf2=1-(tpv2/boxvolume1)
print 'porosity of filter layer2:', nf2

Ss2=S1*pfp2+S2*psp2
print 'S1,S2,Ss2 :', S1,S2,Ss2

e2=nf2/(1-nf2)
k2=(math.sqrt(10)*(e2**3))/((Gs**2)*(Ss2**2)*(1+e2))
print 'void ratio and permeability in layer2 :', e2, k2

print '3rd filter layer information ##########################################################################'
nfp3 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<3.0/5.0*totalThickness+.03 and b.state.pos[2]>2.0/5.0*totalThickness+.03) and b.shape.radius == r1))/r1
print 'number of filter particles in Layer3 :', nfp3
tvfp3=(4.0/3.0*3.1416*r1**3)*nfp3
print 'total volume of filter particles in Layer3 :', tvfp3
############################################################################
nsp3 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<3.0/5.0*totalThickness+.03 and b.state.pos[2]>2.0/5.0*totalThickness+.03) and b.shape.radius == r2))/r2
print 'number of small particles in Layer3 :', nsp3
tvsp3=4.0/3.0*3.1416*(r2**3)*nsp3
print 'total volume of small particles in Layer3  :', tvsp3
##########################################################################
tpv3=tvfp3+tvsp3 
print 'total particles volume in Layer3 :', tpv3
pfp3=(tvfp3/tpv3)
print 'proportion of filter particles in layer3 :', pfp3
psp3=(tvsp3/tpv3)
print 'proportion of small particles in layer3 :', psp3
nf3=1-(tpv3/boxvolume1)
print 'porosity of filter layer3 :', nf3

Ss3=S1*pfp3+S2*psp3
print 'S1,S2,Ss3:', S1,S2,Ss3

e3=nf3/(1-nf3)
k3=(math.sqrt(10)*(e3**3))/((Gs**2)*(Ss3**2)*(1+e3))
print 'void ratio and permeability in layer3 :', e3, k3

print '4th filter layer information ##########################################################################'
nfp4 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<2.0/5.0*totalThickness+.03 and b.state.pos[2]>1.0/5.0*totalThickness+.03) and b.shape.radius == r1))/r1
print 'number of filter particles in Layer4 :', nfp4
tvfp4=(4.0/3.0*3.1416*r1**3)*nfp4
print 'total volume of filter particles in Layer4 :', tvfp4
############################################################################
nsp4 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<2.0/5.0*totalThickness+.03 and b.state.pos[2]>1.0/5.0*totalThickness+.03) and b.shape.radius == r2))/r2
print 'number of small particles in Layer4 :', nsp4
tvsp4=4.0/3.0*3.1416*(r2**3)*nsp4
print 'total volume of small particles in Layer4 :', tvsp4
##########################################################################
tpv4=tvfp4+tvsp4 
print 'total particles volume in Layer4 :', tpv4
pfp4=(tvfp4/tpv4)
print 'proportion of filter particles in layer4 :', pfp4
psp4=(tvsp4/tpv4)
print 'proportion of small particles in layer4 :', psp4
nf4=1-(tpv4/boxvolume1)
print 'porosity of filter layer4 :', nf4

Ss4=S1*pfp4+S2*psp4
print 'S1,S2,Ss4:', S1,S2,Ss4

e4=nf4/(1-nf4)
k4=(math.sqrt(10)*(e4**3))/((Gs**2)*(Ss4**2)*(1+e4))
print 'void ratio and permeability in layer4 :', e4, k4


print '5th filter layer information ##########################################################################'
nfp5 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<1.0/5.0*totalThickness+.03 and b.state.pos[2]>.03) and b.shape.radius == r1))/r1
print 'number of filter particles in Layer5 :', nfp5
tvfp5=(4.0/3.0*3.1416*r1**3)*nfp5
print 'total volume of filter particles in Layer5 :', tvfp5
############################################################################
nsp5 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<1.0/5.0*totalThickness+.03 and b.state.pos[2]>.03) and b.shape.radius == r2))/r2
print 'number of small particles in Layer5 :', nsp5
tvsp5=4.0/3.0*3.1416*(r2**3)*nsp5
print 'total volume of small particles in Layer5 :', tvsp5
##########################################################################
tpv5=tvfp5+tvsp5 
print 'total particles volume in Layer5 :', tpv5
pfp5=(tvfp5/tpv5)
print 'proportion of filter particles in layer5 :', pfp5
psp5=(tvsp5/tpv5)
print 'proportion of small particles in layer5 :', psp5

nf5=1-(tpv5/boxvolume1)
print 'porosity of filter layer5:', nf5

Ss5=S1*pfp5+S2*psp5
print 'S1,S2,Ss5:', S1,S2,Ss5

e5=nf5/(1-nf5)
k5=(math.sqrt(10)*(e5**3))/((Gs**2)*(Ss5**2)*(1+e5))
print 'void ratio and permeability in layer5 :', e5, k5

print 'specimen information##########################################'
nfp=nfp1+nfp2+nfp3+nfp4+nfp5
print 'initial porosity in each layer:', nf1,nf2,nf3,nf4,nf5
print 'number of filter particles:', nfp
nsp=nsp1+nsp2+nsp3+nsp4+nsp5
print 'number of small particles:', nsp

tvfp=(4.0/3.0*3.1416*r1**3)*nfp
print 'total volume of filter particles in specimen :', tvfp
pfp=(tvfp/ParticlesVolume)
print 'proportion of filter particles in specimen :', pfp
tvsp=(4.0/3.0*3.1416*r2**3)*nsp
psp=(tvsp/ParticlesVolume)
print 'proportion of small particles in specimen :', psp

Ss=S1*pfp+S2*psp
print 'S1,S2,Ss:', S1,S2,Ss

############## DRAG FORCE calculation #############################################################
vp1=(4.0/3.0)*3.1416*r1**3 #a filter sphere volume 
vp2=(4.0/3.0)*3.1416*r2**3 #a fine sphere volume 
d1=2*r1 #diameter of a coarse sphere
d2=2*r2 #diameter of a fine sphere
bz1=-.52333*(d1**3)*densitywater*g*100 # buoyancy force on filter particles
bz2=-.52333*(d2**3)*densitywater*g*100 # buoyancy force on fine particles

hl=(h1-.03)/5.0 #height of each filter layer


fdst=100*(dp1/((1-.37)*.019))*-vp2 # drag force on spheres in the fine particles layer
print 'fdst=', fdst

fdf1=100*(dp2/((1-nf1)*hl))*-vp1   # drag force on filter spheres in the 1st filter layer
print 'fdf1=', fdf1
fds1=100*(dp2/((1-nf1)*hl))*-vp2   # drag force on fine spheres in the 1st filter layer
print 'fds1=', fds1

fdf2=100*(dp3/((1-nf2)*hl))*-vp1
print 'fdf2=', fdf2
fds2=100*(dp3/((1-nf2)*hl))*-vp2
print 'fds2=', fds2

fdf3=100*(dp4/((1-nf3)*hl))*-vp1
print 'fdf3=', fdf3
fds3=100*(dp4/((1-nf3)*hl))*-vp2
print 'fds3=', fds3

fdf4=100*(dp5/((1-nf4)*hl))*-vp1
print 'fdf4=', fdf4
fds4=100*(dp5/((1-nf4)*hl))*-vp2
print 'fds4=', fds4

fdf5=100*(dp6/((1-nf5)*hl))*-vp1
print 'fdf5=', fdf5
fds5=100*(dp6/((1-nf5)*hl))*-vp2
print 'fds5=', fds5

########## apply forces on particles ######################################################################################

for b in O.bodies:

    if isinstance(b.shape,Sphere) and (b.state.pos[2]<h1 and b.state.pos[2]>4.0/5.0*totalThickness+.03) and b.shape.radius == r1:
	O.forces.addF(b.id,(0,0,bz1+fdf1),1)
    if isinstance(b.shape,Sphere) and (b.state.pos[2]<4.0/5.0*totalThickness+.03 and b.state.pos[2]>3.0/5.0*totalThickness+.03) and b.shape.radius == r1:
	O.forces.addF(b.id,(0,0,bz1+fdf2),1)
    if isinstance(b.shape,Sphere) and (b.state.pos[2]<3.0/5.0*totalThickness+.03 and b.state.pos[2]>2.0/5.0*totalThickness+.03) and b.shape.radius == r1:
	O.forces.addF(b.id,(0,0,bz1+fdf3),1)
    if isinstance(b.shape,Sphere) and (b.state.pos[2]<2.0/5.0*totalThickness+.03 and b.state.pos[2]>1.0/5.0*totalThickness+.03) and b.shape.radius == r1:
	O.forces.addF(b.id,(0,0,bz1+fdf4),1)
    if isinstance(b.shape,Sphere) and (b.state.pos[2]<1.0/5.0*totalThickness+.03 and b.state.pos[2]>.03) and b.shape.radius == r1:
	O.forces.addF(b.id,(0,0,bz1+fdf5),1)

    elif isinstance(b.shape,Sphere) and (b.state.pos[2]>h1) and b.shape.radius == r2:
	O.forces.addF(b.id,(0,0,bz2+fdst),1)

    elif isinstance(b.shape,Sphere) and (b.state.pos[2]<h1 and b.state.pos[2]>4.0/5.0*totalThickness+.03) and b.shape.radius == r2:
	O.forces.addF(b.id,(0,0,bz2+fds1),1)
    elif isinstance(b.shape,Sphere) and (b.state.pos[2]<4.0/5.0*totalThickness+.03 and b.state.pos[2]>3.0/5.0*totalThickness+.03) and b.shape.radius == r2:
	O.forces.addF(b.id,(0,0,bz2+fds2),1)
    elif isinstance(b.shape,Sphere) and (b.state.pos[2]<3.0/5.0*totalThickness+.03 and b.state.pos[2]>2.0/5.0*totalThickness+.03) and b.shape.radius == r2:
	O.forces.addF(b.id,(0,0,bz2+fds3),1)
    elif isinstance(b.shape,Sphere) and (b.state.pos[2]<2.0/5.0*totalThickness+.03 and b.state.pos[2]>1.0/5.0*totalThickness+.03) and b.shape.radius == r2:
	O.forces.addF(b.id,(0,0,bz2+fds4),1)
    elif isinstance(b.shape,Sphere) and (b.state.pos[2]<1.0/5.0*totalThickness+.03 and b.state.pos[2]>.03) and b.shape.radius == r2:
	O.forces.addF(b.id,(0,0,bz2+fds5),1)

##############################################################################################################################
# the function "func" just repeat previous command lines in Calculation Section   

def func():
    if O.iter>0:
	print 'BOTTOM LAYER INFORMATION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%'
	h1=max(b.state.pos[2]+b.shape.radius for b in O.bodies if isinstance(b.shape,Sphere) and b.shape.radius==r1)
	print 'h1=', h1
	ParticlesVolume=sum(4.0/3.0*3.1416*b.shape.radius**3 for b in O.bodies if (isinstance (b.shape,Sphere) and (b.state.pos[2]<h1 and b.state.pos[2]>.03)))
	print 'ParticlesVolume=', ParticlesVolume
	boxArea=.01*.01
	BoxVolume=(h1-.03)*boxArea
	print 'BoxVolume=', BoxVolume
	n1=1-(ParticlesVolume/BoxVolume)
	print 'porosity of bottom layer :', n1

	print '1st FILTER layer information##########################################################################'
	totalThickness=h1-.03
	boxvolume1=boxArea*totalThickness*1.0/5.0
	print 'boxvolume1 :', boxvolume1
	nfp1 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<h1 and b.state.pos[2]>4.0/5.0*totalThickness+.03) and b.shape.radius == r1))/r1
	print 'number of filter particles in Layer1 :', nfp1
	tvfp1=(4.0/3.0*3.1416*r1**3)*nfp1
	print 'total volume of filter particles in Layer1 :', tvfp1
	############################################################################
	nsp1 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<h1 and b.state.pos[2]>4.0/5.0*totalThickness+.03) and b.shape.radius == r2))/r2
	print 'number of small particles in Layer1 :', nsp1
	tvsp1=4.0/3.0*3.1416*(r2**3)*nsp1
	print 'total volume of small particles in Layer1 :', tvsp1
	##########################################################################
	tpv1=tvfp1+tvsp1 
	print 'total particles volume in Layer1 :', tpv1
	pfp1=(tvfp1/tpv1)
	print 'proportion of filter particles in layer1 :', pfp1
	psp1=(tvsp1/tpv1)
	print 'proportion of small particles in layer1 :', psp1
	global nf1
	nf1=1-(tpv1/boxvolume1)
	print 'porosity of filter layer1 :', nf1

	S1=3/(r1*density1)  #m2/kg
	S2=3/(r2*density2)
	Ss1=S1*pfp1+S2*psp1
	print 'S1,S2,Ss1:', S1,S2,Ss1

	e1=nf1/(1-nf1)
	global k1
	k1=(math.sqrt(10)*(e1**3))/((Gs**2)*(Ss1**2)*(1+e1))
	print 'void ratio and permeability in layer1 :', e1, k1

	print '2nd FILTER layer information ##########################################################################'
	nfp2 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<4.0/5.0*totalThickness+.03 and b.state.pos[2]>3.0/5.0*totalThickness+.03) and b.shape.radius == r1))/r1
	print 'number of filter particles in Layer2 :', nfp2
	tvfp2=(4.0/3.0*3.1416*r1**3)*nfp2
	print 't1otal volume of filter particles in Layer2 :', tvfp2
	############################################################################
	nsp2 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<4.0/5.0*totalThickness+.03 and b.state.pos[2]>3.0/5.0*totalThickness+.03) and b.shape.radius == r2))/r2
	print 'number of small particles in Layer2 :', nsp2
	tvsp2=4.0/3.0*3.1416*(r2**3)*nsp2
	print 'total volume of small particles in Layer2 :', tvsp2
	##########################################################################
	tpv2=tvfp2+tvsp2 
	print 'total particles volume in Layer2 :', tpv2
	pfp2=(tvfp2/tpv2)
	print 'proportion of filter particles in layer2 :', pfp2
	psp2=(tvsp2/tpv2)
	print 'proportion of small particles in laye2 :', psp2
	global nf2
	nf2=1-(tpv2/boxvolume1)
	print 'porosity of filter layer2 :', nf2

	Ss2=S1*pfp2+S2*psp2
	print 'S1,S2,Ss2:', S1,S2,Ss2

	e2=nf2/(1-nf2)
	global k2
	k2=(math.sqrt(10)*(e2**3))/((Gs**2)*(Ss2**2)*(1+e2))
	print 'void ratio and permeability in layer2 :', e2, k2

	print '3rd FILTER layer information ##########################################################################'
	nfp3 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<3.0/5.0*totalThickness+.03 and b.state.pos[2]>2.0/5.0*totalThickness+.03) and b.shape.radius == r1))/r1
	print 'number of filter particles in Layer3 :', nfp3
	tvfp3=(4.0/3.0*3.1416*r1**3)*nfp3
	print 'total volume of filter particles in Layer3 :', tvfp3
	############################################################################
	nsp3 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<3.0/5.0*totalThickness+.03 and b.state.pos[2]>2.0/5.0*totalThickness+.03) and b.shape.radius == r2))/r2
	print 'number of small particles in Layer3 :', nsp3
	tvsp3=4.0/3.0*3.1416*(r2**3)*nsp3
	print 'total volume of small particles in Layer3 :', tvsp3
	##########################################################################
	tpv3=tvfp3+tvsp3 
	print 'total particles volume in Layer3 :', tpv3
	pfp3=(tvfp3/tpv3)
	print 'proportion of filter particles in layer3:', pfp3
	psp3=(tvsp3/tpv3)
	print 'proportion of small particles in layer3:', psp3
	global nf3
	nf3=1-(tpv3/boxvolume1)
	print 'porosity of filter layer3 :', nf3

	Ss3=S1*pfp3+S2*psp3
	print 'S1,S2,Ss3:', S1,S2,Ss3

	e3=nf3/(1-nf3)
	global k3
	k3=(math.sqrt(10)*(e3**3))/((Gs**2)*(Ss3**2)*(1+e3))
	print 'void ratio and permeability in layer3 :', e3, k3

	print '4th FILTER layer information ##########################################################################'
	nfp4 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<2.0/5.0*totalThickness+.03 and b.state.pos[2]>1.0/5.0*totalThickness+.03) and b.shape.radius == r1))/r1
	print 'number of filter particles in Layer4 :', nfp4
	tvfp4=(4.0/3.0*3.1416*r1**3)*nfp4
	print 'total volume of filter particles in Layer4 :', tvfp4
	############################################################################
	nsp4 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<2.0/5.0*totalThickness+.03 and b.state.pos[2]>1.0/5.0*totalThickness+.03) and b.shape.radius == r2))/r2
	print 'number of small particles in Layer4 :', nsp4
	tvsp4=4.0/3.0*3.1416*(r2**3)*nsp4
	print 'total volume of small particles in Layer4 :', tvsp4
	##########################################################################
	tpv4=tvfp4+tvsp4 
	print 'total particles volume in Layer4 :', tpv4
	pfp4=(tvfp4/tpv4)
	print 'proportion of filter particles in layer4 :', pfp4
	psp4=(tvsp4/tpv4)
	print 'proportion of small particles in layer4 :', psp4
	global nf4
	nf4=1-(tpv4/boxvolume1)
	print 'porosity of filter layer4 :', nf4

	Ss4=S1*pfp4+S2*psp4
	print 'S1,S2,Ss4:', S1,S2,Ss4

	e4=nf4/(1-nf4)
	global k4
	k4=(math.sqrt(10)*(e4**3))/((Gs**2)*(Ss4**2)*(1+e4))
	print 'void ratio and permeability in layer4 :', e4, k4


	print '5th FILTER layer information ##########################################################################'
	nfp5 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<1.0/5.0*totalThickness+.03 and b.state.pos[2]>.03) and b.shape.radius == r1))/r1
	print 'number of filter particles in Layer5 :', nfp5
	tvfp5=(4.0/3.0*3.1416*r1**3)*nfp5
	print 'total volume of filter particles in Layer5 :', tvfp5
	############################################################################
	nsp5 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<1.0/5.0*totalThickness+.03 and b.state.pos[2]>.03) and b.shape.radius == r2))/r2
	print 'number of small particles in Layer5 :', nsp5
	tvsp5=4.0/3.0*3.1416*(r2**3)*nsp5
	print 'total volume of small particles in Layer5 :', tvsp5
	##########################################################################
	tpv5=tvfp5+tvsp5 
	print 'total particles volume in Layer5 :', tpv5
	pfp5=(tvfp5/tpv5)
	print 'proportion of filter particles in layer5 :', pfp5
	psp5=(tvsp5/tpv5)
	print 'proportion of small particles in layer5 :', psp5
	global nf5
	nf5=1-(tpv5/boxvolume1)
	print 'porosity of filter layer5:', nf5

	Ss5=S1*pfp5+S2*psp5
	print 'S1,S2,Ss5:', S1,S2,Ss5

	e5=nf5/(1-nf5)
	global k5
	k5=(math.sqrt(10)*(e5**3))/((Gs**2)*(Ss5**2)*(1+e5))
	print 'void ratio and permeability in layer5 :', e5, k5

	print 'Container information##########################################'
        global npc2,npc3
	npc2 = sum(b.shape.radius for b in O.bodies if (isinstance(b.shape,Sphere) and (b.state.pos[2]<.03) and b.shape.radius == r2))/r2
	print 'number of small particles in the container :', npc2

	print 'specimen information##########################################'

	nfp=nfp1+nfp2+nfp3+nfp4+nfp5
	print 'initial porosity in each layer:', nf1,nf2,nf3,nf4,nf5
	print 'number of filter particles:', nfp
	nsp=nsp1+nsp2+nsp3+nsp4+nsp5
	print 'number of small particles:', nsp

	tvfp=(4.0/3.0*3.1416*r1**3)*nfp
	print 'total volume of filter particles in specimen :', tvfp
	pfp=(tvfp/ParticlesVolume)
	print 'proportion of filter particles in specimen:', pfp
	tvsp=(4.0/3.0*3.1416*r2**3)*nsp
	psp=(tvsp/ParticlesVolume)
	print 'proportion of small particles in specimen:', psp

	Ss=S1*pfp+S2*psp
	print 'S1,S2,Ss:', S1,S2,Ss


	############## DRAG FORCE calculation #############################################################
	vp1=(4.0/3.0)*3.1416*r1**3
	vp2=(4.0/3.0)*3.1416*r2**3
	d1=2*r1
	d2=2*r2
	bz1=-.52333*(d1**3)*densitywater*g*100
	bz2=-.52333*(d2**3)*densitywater*g*100
	print 'buoyancy1,2:', bz1, bz2

	hl=(h1-.03)/5.0

	fdst=100*(dp1/((1-.37)*.019))*-vp2
	print 'fdst=', fdst

	fdf1=100*(dp2/((1-nf1)*hl))*-vp1
	print 'fdf1=', fdf1
	fds1=100*(dp2/((1-nf1)*hl))*-vp2
	print 'fds1=', fds1

	fdf2=100*(dp3/((1-nf2)*hl))*-vp1
	print 'fdf2=', fdf2
	fds2=100*(dp3/((1-nf2)*hl))*-vp2
	print 'fds2=', fds2

	fdf3=100*(dp4/((1-nf3)*hl))*-vp1
	print 'fdf3=', fdf3
	fds3=100*(dp4/((1-nf3)*hl))*-vp2
	print 'fds3=', fds3

	fdf4=100*(dp5/((1-nf4)*hl))*-vp1
	print 'fdf4=', fdf4
	fds4=100*(dp5/((1-nf4)*hl))*-vp2
	print 'fds4=', fds4

	fdf5=100*(dp6/((1-nf5)*hl))*-vp1
	print 'fdf5=', fdf5
	fds5=100*(dp6/((1-nf5)*hl))*-vp2
	print 'fds5=', fds5

        ########## apply forces on particles ######################################################################################
	for b in O.bodies:

	    if isinstance(b.shape,Sphere) and (b.state.pos[2]<h1 and b.state.pos[2]>4.0/5.0*totalThickness+.03) and b.shape.radius == r1:
		O.forces.addF(b.id,(0,0,bz1+fdf1),1)
	    if isinstance(b.shape,Sphere) and (b.state.pos[2]<4.0/5.0*totalThickness+.03 and b.state.pos[2]>3.0/5.0*totalThickness+.03) and b.shape.radius == r1:
		O.forces.addF(b.id,(0,0,bz1+fdf2),1)
	    if isinstance(b.shape,Sphere) and (b.state.pos[2]<3.0/5.0*totalThickness+.03 and b.state.pos[2]>2.0/5.0*totalThickness+.03) and b.shape.radius == r1:
		O.forces.addF(b.id,(0,0,bz1+fdf3),1)
	    if isinstance(b.shape,Sphere) and (b.state.pos[2]<2.0/5.0*totalThickness+.03 and b.state.pos[2]>1.0/5.0*totalThickness+.03) and b.shape.radius == r1:
		O.forces.addF(b.id,(0,0,bz1+fdf4),1)
	    if isinstance(b.shape,Sphere) and (b.state.pos[2]<1.0/5.0*totalThickness+.03 and b.state.pos[2]>.03) and b.shape.radius == r1:
		O.forces.addF(b.id,(0,0,bz1+fdf5),1)

	    elif isinstance(b.shape,Sphere) and (b.state.pos[2]>h1) and b.shape.radius == r2:
		O.forces.addF(b.id,(0,0,bz2+fdst),1)

	    elif isinstance(b.shape,Sphere) and (b.state.pos[2]<h1 and b.state.pos[2]>4.0/5.0*totalThickness+.03) and b.shape.radius == r2:
		O.forces.addF(b.id,(0,0,bz2+fds1),1)
	    elif isinstance(b.shape,Sphere) and (b.state.pos[2]<4.0/5.0*totalThickness+.03 and b.state.pos[2]>3.0/5.0*totalThickness+.03) and b.shape.radius == r2:
		O.forces.addF(b.id,(0,0,bz2+fds2),1)
	    elif isinstance(b.shape,Sphere) and (b.state.pos[2]<3.0/5.0*totalThickness+.03 and b.state.pos[2]>2.0/5.0*totalThickness+.03) and b.shape.radius == r2:
		O.forces.addF(b.id,(0,0,bz2+fds3),1)
	    elif isinstance(b.shape,Sphere) and (b.state.pos[2]<2.0/5.0*totalThickness+.03 and b.state.pos[2]>1.0/5.0*totalThickness+.03) and b.shape.radius == r2:
		O.forces.addF(b.id,(0,0,bz2+fds4),1)
	    elif isinstance(b.shape,Sphere) and (b.state.pos[2]<1.0/5.0*totalThickness+.03 and b.state.pos[2]>.03) and b.shape.radius == r2:
		O.forces.addF(b.id,(0,0,bz2+fds5),1)

	print '********************************************'
        print 'O.time :', O.time


def save():
    if O.time>.0:
        global nf1,nf2,nf3,nf4,nf5,k1,k2,k3,k4,k5,npc,npc2, h1, counter
	npc=npc2+npc3
        npc=int(npc) 
	print 'h1, npc :', h1, npc
        plot.addData(n1=nf1,n2=nf2,n3=nf3,n4=nf4,n5=nf5,k1=k1,k2=k2,k3=k3,k4=k4,k5=k5,nc=npc) #selected parameters will be written on the text file

	counterint=int(float(counter))
	ncint=counterint+1
	ncstr=str(ncint) 
	print 'countersave:', ncstr
	O.save("test"+ncstr+".yade")    # save current simulation to file name.yade 
        plot.saveDataTxt('yaderesults.txt')  # save the results in yaderesults.txt
        O.pause()

O.saveTmp()
O.run()
O.wait()
quit()






